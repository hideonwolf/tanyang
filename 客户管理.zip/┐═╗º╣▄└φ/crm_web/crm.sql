CREATE TABLE `role` (
`r_id`  int NOT NULL AUTO_INCREMENT ,
`r_name`  varchar(50) NOT NULL ,
`r_desc`  varchar(200) CHARACTER SET utf8 NULL ,
PRIMARY KEY (`r_id`)
)
;

CREATE TABLE `user` (
`u_id`  int NOT NULL AUTO_INCREMENT ,
`u_name`  varchar(50) NOT NULL ,
`u_password`  varchar(50) NOT NULL ,
`r_id`  int NOT NULL ,
PRIMARY KEY (`u_id`),
CONSTRAINT `role_id` FOREIGN KEY (`r_id`) REFERENCES `role` (`r_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
;


CREATE TABLE `sale_chance` (
`sc_id`  int NOT NULL AUTO_INCREMENT ,
`sc_cusname`  varchar(200) NOT NULL ,
`sc_comming`  varchar(100) NULL ,
`sc_name`  varchar(50) NULL ,
`sc_phone`  varchar(20) NULL ,
`sc_success`  varchar(20) NULL ,
`sc_message`  varchar(300) NULL ,
`sc_desc`  varchar(200) NULL ,
`sc_user`  varchar(50) NULL ,
`sc_createtime`  datetime NULL ,
`sc_giveuser`  varchar(50) NULL ,
`sc_givetime`  datetime NULL ,
`sc_status` int,
PRIMARY KEY (`sc_id`)
)
;
-- 开发计划
CREATE TABLE `dev_plan` (
`dp_id`  int NOT NULL AUTO_INCREMENT ,
`dp_plandate`  datetime NULL ,
`dp_plancontent`  varchar(300) NULL ,
`dp_execase`  varchar(300) NULL ,
`dp_exedate`  datetime NULL ,
`dp_exemanager`  varchar(100) NULL ,
`sc_id`  int NOT NULL ,
PRIMARY KEY (`dp_id`),
CONSTRAINT `d_p` FOREIGN KEY (`sc_id`) REFERENCES `sale_chance` (`sc_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
;

-- 客户表
CREATE TABLE `crm` ( `cus_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '客户编号', 
`cus_name` varchar(50) CHARACTER SET utf8 
COLLATE utf8_general_ci NOT NULL COMMENT '客户名称',
 `cus_region` int(11) NOT NULL
  COMMENT '客户地区。1-东北，2-华北，3-西北，4-西南，5-华南，6-华中，7-华东',
   `cus_industry` int(11) NOT NULL 
   COMMENT '客户行业. 1-金融，2-房地产，3-商业服务，4-运输物流，
   5-生产，6-政府，7-文化传媒，8-其它', `cus_level` char(1) 
   CHARACTER SET utf8 COLLATE utf8_general_ci 
   NOT NULL COMMENT '客户等级. A-重点客户；B-普通客户；C-非优先客户',
    `cus_satisfy` int(11) NOT NULL 
    COMMENT '客户满意度. 1-一级，2-二级，3-三级，4-四级，5-五级',
     `cus_credit` int(11) NOT NULL 
     COMMENT '客户信用度. 1-一级，2-二级，3-三级，4-四级，5-五级', 
     `cus_addr` varchar(100) CHARACTER SET utf8 
     COLLATE utf8_general_ci NOT NULL COMMENT
      '客户地址', `cus_zipcode` int(6) NOT NULL COMMENT 
      '客户邮编', `cus_phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客户电话', `cus_fax` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客户传真', `cus_url` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '客户网址', `user_id` int(11) NOT NULL COMMENT '客户经理id', `cus_status` int(11) NOT NULL COMMENT '客户状态.1-正常，0-流失', PRIMARY KEY (`cus_id`) USING BTREE ) ENGINE = InnoDB AUTO_INCREMENT = 1
 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
-- 客户联系人




